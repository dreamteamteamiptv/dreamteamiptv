# -*- coding: utf-8 -*-
#------------------------------------------------------------
# XBMC Add-on for Dream Stream IPTV
# Version 0.0.2
#------------------------------------------------------------

import xbmc, xbmcaddon, xbmcgui, xbmcplugin,os,base64,sys,xbmcvfs
import shutil
import urllib2,urllib
import re
import time
import plugintools


plugin_handle = int(sys.argv[1])
USER_AGENT = 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3'
addon_id = 'plugin.video.dreamstream'
ADDON = xbmcaddon.Addon(id=addon_id)
AddonID='plugin.video.dreamstream'
AddonTitle="Dream Stream"
FANART = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id , 'fanart.jpg'))
ICON = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id, 'icon.png'))
ART = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id + '/resources/art/'))
VERSION = "0.0.2"
PATH = "Dream Stream"
#Login credentials
USER= ADDON.getSetting('username')
PASSWORD= ADDON.getSetting('password')
BASEURL = "http://dreamstream.com"

def add_video_item(url, infolabels, img=''):
    listitem = xbmcgui.ListItem(infolabels['title'], iconImage=img, thumbnailImage=img)
    listitem.setInfo('video', infolabels)
    listitem.setProperty('IsPlayable', 'true')
    xbmcplugin.addDirectoryItem(plugin_handle, url, listitem, isFolder=False)

def INDEX():
    addDir('UK',BASEURL,2,ART+'icon.png',FANART,'')
    addDir('UK_MOVIES',BASEURL,3,ART+'icon.png',FANART,'')
    addDir('UK_SPORTS',BASEURL,4,ART+'icon.png',FANART,'')
    addDir('UK_DOCUMENTARIES',BASEURL,6,ART+'icon.png',FANART,'')
    addDir('UK_ENTERTAINMENT',BASEURL,7,ART+'icon.png',FANART,'')
    addDir('UK_KIDS',BASEURL,8,ART+'icon.png',FANART,'')
    addDir('UK_INDIAN',BASEURL,9,ART+'icon.png',FANART,'')
    addDir('EURO_SPORTS',BASEURL,10,ART+'icon.png',FANART,'')
    addDir('UK_MUSIC',BASEURL,11,ART+'icon.png',FANART,'')
    addDir('USA TV',BASEURL,12,ART+'icon.png',FANART,'')
	
	

def UK():
    add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/638.ts',{ 'title': 'ITV1'}, '%s/itv1hd.png'% ART)
    add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/639.ts',{ 'title': 'ITV 2'}, '%s/itv2hd.png'% ART)
    add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/640.ts',{ 'title': 'ITV 3'}, '%s/itv3hd.png'% ART)
    add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/641.ts',{ 'title': 'ITV 4'}, '%s/itv4hd.png'% ART)
    add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/1484.ts',{ 'title': 'ITV Be'}, '%s/itvbe.png'% ART)
    add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/664.ts',{ 'title': 'Channel 4'}, '%s/channel4hd.png'% ART)
    add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/665.ts',{ 'title': 'Channel 5'}, '%s/channel5.png'% ART)
    add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/633.ts',{ 'title': 'BBC 1'}, '%s/bbc1hd.png'% ART)
    add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/634.ts',{ 'title': 'BBC 2'}, '%s/bbc2.png'% ART)
    add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/635.ts',{ 'title': 'BBC 3'}, '%s/bbcthree.png'% ART)
    add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/636.ts',{ 'title': 'BBC 4'}, '%s/bbc4.png'% ART)
    
def UK_MOVIES():
	add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/1995.ts',{ 'title': 'SKY Movies Showcase'}, '%s/showcase.png'% ART)
	add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/627.ts',{ 'title': 'SKY Movies Select'}, '%s/select.png'% ART)
	add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/601.ts',{ 'title': 'SKY Movies SCI-FI & Horror'}, '%s/horror.png'% ART)
	add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/602.ts',{ 'title': 'SKY Movies Premiere'}, '%s/premiere.png'% ART)
	add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/603.ts',{ 'title': 'SKY Movies Greats'}, '%s/modern.png'% ART)
	add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/604.ts',{ 'title': 'SKY Movies Family'}, '%s/family.png'% ART)
	add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/605.ts',{ 'title': 'SKY Movies Drama & Romance'}, '%s/classics.png'% ART)
	add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/606.ts',{ 'title': 'SKY movies Disney'}, '%s/skydisney.jpg'% ART)
	add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/600.ts',{ 'title': 'SKY Movies Crime & Thriller'}, '%s/crimehd.png'% ART)
	add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/608.ts',{ 'title': 'SKY Movies Comedy'}, '%s/comedy.png'% ART)
	add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/609.ts',{ 'title': 'SKY Movies Action - Adventure'}, '%s/skyaction.png'% ART)

def UK_SPORTS():
    add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/1527.ts',{ 'title': 'Sky Sports 1 HD'}, '%s/skysportshd1.png'% ART)
    add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/15.ts',{ 'title': 'Sky Sports 1'}, '%s/skysports1.png'% ART)
    add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/1526.ts',{ 'title': 'Sky Sports 2 HD'}, '%s/skysportshd2.png'% ART)
    add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/16.ts',{ 'title': 'Sky Sports 2'}, '%s/sky sports2.png'% ART)
    add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/1525.ts',{ 'title': 'Sky Sports 3 HD'}, '%s/skysporthd3.png'% ART)
    add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/17.ts',{ 'title': 'Sky Sports 3'}, '%s/skysports3.png'% ART)
    add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/1524.ts',{ 'title': 'Sky Sports 4 HD'}, '%s/skysportshd4.png'% ART)
    add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/18.ts',{ 'title': 'Sky Sports 4'}, '%s/skyspors4.png'% ART)
    add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/1523.ts',{ 'title': 'Sky Sports 5 HD'}, '%s/skysport5.png'% ART)
    add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/19.ts',{ 'title': 'Sky Sports 5'}, '%s/skysport5.png'% ART)
    add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/595.ts',{ 'title': 'Sky Sports News'}, '%s/skysportsnews.png'% ART) 
    add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/596.ts',{ 'title': 'Sky Sports F1 HD'}, '%s/f1hd.png'% ART)
    add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/4.ts',{ 'title': 'Setanta Sports'}, '%s/setanta.png'% ART)
    add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/540.ts',{ 'title': 'ESPN'}, '%s/espnhd.png'% ART)
    add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/20.ts',{ 'title': 'BT Sport 1'}, '%s/btsport1.png'% ART)
    add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/1697.ts',{ 'title': 'BT Sport 1 HD'}, '%s/btsport1.png'% ART)
    add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/21.ts',{ 'title': 'BT Sport 2'}, '%s/btsport2.png'% ART)
    add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/1791.ts',{ 'title': 'BT Sport 2 HD'}, '%s/btsport2.png'% ART)
    add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/1741.ts',{ 'title': 'BT SPORT EUROPE HD'}, '%s/btsporteur.jpeg'% ART)
    add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/2014.ts',{ 'title': 'BT Sport Europe HD ( Back Up )'}, '%s/btsporteur.jpg'% ART)
    add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/1794.ts',{ 'title': 'BT Sport ESPN'}, '%s/btsportespn.jpg'% ART)
    add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/1739.ts',{ 'title': 'BT Sport Extra'}, '%s/btextra.jpg'% ART)
    add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/597.ts',{ 'title': 'Premier Sports HD'}, '%s/premiersports.png'% ART)
    add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/681.ts',{ 'title': 'Eurosport HD'}, '%s/eurosportuk.png'% ART)
    add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/680.ts',{ 'title': 'Eurosport 2 HD'}, '%s/eurosport2uk.png'% ART)
    add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/611.ts',{ 'title': 'Liverpool TV'}, '%s/liverpoolfctv.png'% ART)
    add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/623.ts',{ 'title': 'MUTV'}, '%s/mutv.png'% ART)
    add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/661.ts',{ 'title': 'Chelsea TV'}, '%s/chelsea.jpg'% ART)
    add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/667.ts',{ 'title': 'Box Nation'}, '%s/box.jpg'% ART)
    add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/668.ts',{ 'title': 'At The Races'}, '%s/aatheraces.png'% ART)
    add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/617.ts',{ 'title': 'Racing UK'}, '%s/racinguk.png'% ART)
    add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/630.ts',{ 'title': 'Motors TV UK'}, '%s/motorstv.png'% ART)

def UK_DOCUMENTARIES():
    add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/658.ts',{ 'title': 'Discovery'}, '%s/discovery.png'% ART)
    add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/657.ts',{ 'title': 'Discovery History'}, '%s/discoveryhis.png'% ART)
    add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/656.ts',{ 'title': 'Discovery Science'}, '%s/science.png'% ART)
    add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/651.ts',{ 'title': 'Invest Discovery'}, '%s/dicsoveryid.png'% ART)
    add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/653.ts',{ 'title': 'National Geographic'}, '%s/nationalgeo.png'% ART)
    add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/652.ts',{ 'title': 'Nat Geo Wild'}, '%s/natgeowild.png'% ART)
    add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/654.ts',{ 'title': 'TRAVEL'}, '%s/travel.jpg'% ART)
    add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/676.ts',{ 'title': 'TLC'}, '%s/tlc.png'% ART)
    add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/655.ts',{ 'title': 'Animal Planet'}, '%s/animal.png'% ART)
    add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/650.ts',{ 'title': 'History'}, '%s/history.png'% ART)
    add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/1473.ts',{ 'title': 'Eden'}, '%s/eden.png'% ART)
	
def UK_ENTERTAINMENT():
    add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/672.ts',{ 'title': '3E'}, '%s/32.jpg'% ART)
    add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/670.ts',{ 'title': '5 USA'}, '%s/5usa.png'% ART)
    add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/671.ts',{ 'title': '5 STAR'}, '%s/5star.png'% ART)
    add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/1477.ts',{ 'title': 'Alibi'}, '%s/alibi.png'% ART)
    add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/659.ts',{ 'title': 'Comedy Central'}, '%s/comedycen.png'% ART)
    add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/660.ts',{ 'title': 'Clubland'}, '%s/club.jpg'% ART)
    add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/664.ts',{ 'title': 'Channel 4'}, '%s/chan4.jpg'% ART)
    add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/665.ts',{ 'title': 'Channel 5'}, '%s/5hd.png'% ART)
    add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/666.ts',{ 'title': 'CBS Drama'}, '%s/cbsdrama.png'% ART)
    add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/1483.ts',{ 'title': 'CBS Reality'}, '%s/cbsreality.png'% ART)
    add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/684.ts',{ 'title': 'Dave'}, '%s/dave.png'% ART)
    add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/647.ts',{ 'title': 'Drama'}, '%s/drama.jpg'% ART)
    add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/683.ts',{ 'title': 'Dmax'}, '%s/dmax.jpg'% ART)
    add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/1141.ts',{ 'title': 'Good Food'}, '%s/goodfood.png'% ART)
    add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/642.ts',{ 'title': 'Gold'}, '%s/gold.png'% ART)
    add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/1139.ts',{ 'title': 'Home'}, '%s/home.png'% ART)
    add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/646.ts',{ 'title': 'E4'}, '%s/e4.png'% ART)
    add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/1897.ts',{ 'title': 'Euronews'}, '%s/euro.png'% ART)
    add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/1910.ts',{ 'title': 'Fashion TV'}, '%s/fashion.png'% ART)
    add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/643.ts',{ 'title': 'Fox'}, '%s/fox.png'% ART)
    add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/1143.ts',{ 'title': 'Food Network'}, '%s/foodnetwork.png'% ART)
    add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/644.ts',{ 'title': 'Five'}, '%s/five.png'% ART)
    add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/645.ts',{ 'title': 'Film 4'}, '%s/film4.png'% ART)
    add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/624.ts',{ 'title': 'MTV Music'}, '%s/mtv.png'% ART)
    add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/625.ts',{ 'title': 'MTV Hits'}, '%s/hits.png'% ART)
    add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/626.ts',{ 'title': 'MTV LIVE HD'}, '%s/mtvlive.jpg'% ART)
    add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/677.ts',{ 'title': 'MTV Classic'}, '%s/mtvclass.png'% ART)
    add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/628.ts',{ 'title': 'Movies Premiere 1'}, '%s/premier1.png'% ART)
    add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/629.ts',{ 'title': 'Movies 4 Men'}, '%s/movies4men.png'% ART)
    add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/631.ts',{ 'title': 'More 4'}, '%s/more4.png'% ART)
    add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/1894.ts',{ 'title': 'London Live'}, '%s/london.jpg'% ART)
    add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/1469.ts',{ 'title': 'Pick'}, '%s/pick.jpg'% ART)
    add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/615.ts',{ 'title': 'RTE 1'}, '%s/rteone.png'% ART)
    add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/616.ts',{ 'title': 'RTE 2'}, '%s/rtetwo.png'% ART)
    add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/1480.ts',{ 'title': 'QUEST'}, '%s/quest.png'% ART)
    add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/1878.ts',{ 'title': 'SKY News'}, '%s/skynews.png'% ART)
    add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/613.ts',{ 'title': 'SKY Art 1'}, '%s/skyarts1hd.png'% ART)
    add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/1927.ts',{ 'title': 'SKY Arts 2'}, '%s/skyarts2hd.png'% ART)
    add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/618.ts',{ 'title': 'SKY 1'}, '%s/sky1.png'% ART)
    add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/594.ts',{ 'title': 'SKY 2'}, '%s/sky2.png'% ART)
    add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/593.ts',{ 'title': 'SYFY'}, '%s/syfy.jpg'% ART)
    add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/610.ts',{ 'title': 'SKY Living'}, '%s/living.png'% ART)
    add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/612.ts',{ 'title': 'SKY Atlantic'}, '%s/atlantic.png'% ART)
    add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/1926.ts',{ 'title': 'The Vault'}, '%s/vault.png'% ART)
    add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/591.ts',{ 'title': 'TRUE MOVIES 1'}, '%s/truemovies.png'% ART)
    add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/673.ts',{ 'title': 'True Movies 2'}, '%s/truemovies2.png'% ART)
    add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/674.ts',{ 'title': 'True Entertainment'}, '%s/true.png'% ART)
    add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/675.ts',{ 'title': 'True Drama'}, '%s/truedrama.png'% ART)
    add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/592.ts',{ 'title': ' TG4'}, '%s/tg4.jpg'% ART)
    add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/589.ts',{ 'title': 'VH1'}, '%s/vh1.png'% ART)
    add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/590.ts',{ 'title': 'TV3'}, '%s/tv3.png'% ART)
    add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/1925.ts',{ 'title': 'Yesterday'}, '%s/yesterday.png'% ART)
    add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/1465.ts',{ 'title': 'Watch'}, '%s/watch.jpg'% ART)
	 
def UK_KIDS():
    add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/649.ts',{ 'title': 'Disney'}, '%s/disney.png'% ART)
    add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/620.ts',{ 'title': 'Disney_XD'}, '%s/disneyxd.png'% ART)
    add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/648.ts',{ 'title': 'Disney_junior'}, '%s/disneyjun.jpg'% ART)
    add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/1774.ts',{ 'title': 'Disney XD'}, '%s/disneyxd.png'% ART)
    add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/1844.ts',{ 'title': 'RTE jr'}, '%s/rtejnr.jpg'% ART)
    add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/1479.ts',{ 'title': 'BABY TV'}, '%s/babytv.png'% ART)
    add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/1506.ts',{ 'title': 'Cartoonito'}, '%s/cartoonito.png'% ART)
    add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/1475.ts',{ 'title': 'Cartoon Network'}, '%s/cartoonnetwork.png'% ART)
    add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/621.ts',{ 'title': 'Nicktoons'}, '%s/nicktoons.png'% ART)
    add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/622.ts',{ 'title': 'Nickelodeon'}, '%s/nickleoden.png'% ART)
    add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/1138.ts',{ 'title': 'UK: Nick JR'}, '%s/nickjr.png'% ART)
    add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/1472.ts',{ 'title': 'Kix'}, '%s/kix.jpg'% ART)
    add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/1137.ts',{ 'title': 'UK: POP'}, '%s/pop.png'% ART)
    add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/1136.ts',{ 'title': 'Pop Girl'}, '%s/popgirl.png'% ART)
	
def UK_INDIAN():
    add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/1573.ts',{ 'title': 'Colors'}, '%s/colors.jpg'% ART)
    add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/1576.ts',{ 'title': 'Zoom'}, '%s/zoom.png'% ART)
    add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/1571.ts',{ 'title': 'ZEE TV'}, '%s/zeetv.png'% ART)
    add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/1572.ts',{ 'title': 'ZEE Cinema'}, '%s/zeecinema.png'% ART)
    add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/1575.ts',{ 'title': 'Sony Entertainment'}, '%s/sonyent.jpg'% ART)
    add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/1574.ts',{ 'title': 'SETMAX'}, '%s/max.png'% ART)
    add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/2034.ts',{ 'title': 'Star Plus HD'}, '%s/starplus.jpg'% ART)
    add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/2035.ts',{ 'title': 'Pogo'}, '%s/pogo.jpg'% ART)
    add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/2032.ts',{ 'title': 'B4U Aflam'}, '%s/b4uaf.jpg'% ART)
    add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/2030.ts',{ 'title': 'Hum tv'}, '%s/hum.png'% ART)
    add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/2031.ts',{ 'title': 'B4U PLUS'}, '%s/b4uplus.jpg'% ART)
    add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/2029.ts',{ 'title': 'Life OK'}, '%s/life.jpg'% ART)
    add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/2027.ts',{ 'title': 'Rishtey'}, '%s/rish.jpg'% ART)
    add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/2025.ts',{ 'title': 'Zing'}, '%s/zing.png'% ART)
    add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/2026.ts',{ 'title': 'BritAsia'}, '%s/brita.jpg'% ART)
    add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/2022.ts',{ 'title': 'Music India'}, '%s/musica.png'% ART)
    add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/2015.ts',{ 'title': 'Sab TV'}, '%s/sab.jpg'% ART)
    add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/2017.ts',{ 'title': 'Zee Punjabi'}, '%s/zeepunjabi.png'% ART)
    add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/2018.ts',{ 'title': 'Zee Action'}, '%s/actionzee.jpg'% ART)
    add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/2020.ts',{ 'title': 'UTV Movies'}, '%s/utv.jpg'% ART)
    add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/2059.ts',{ 'title': 'Ary Musik'}, '%s/ary.jpg'% ART)
    
def EURO_SPORTS():	

    add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/365.ts',{ 'title': 'BEINSPORTS 1 HD'}, '%s/bein1.jpg'% ART)
    add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/351.ts',{ 'title': 'BEINSPORTS 2 HD'}, '%s/bein2.jpg'% ART)
    add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/352.ts',{ 'title': 'BEINSPORTS 3 HD'}, '%s/bein3.jpg'% ART)
    add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/353.ts',{ 'title': 'BEINSPORTS 4 HD'}, '%s/bein4.png'% ART)
    add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/354.ts',{ 'title': 'BEINSPORTS 5 HD'}, '%s/bein5.png'% ART)
    add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/355.ts',{ 'title': 'BEINSPORTS 6 HD'}, '%s/bein6.png'% ART)
    add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/356.ts',{ 'title': 'BEINSPORTS 7 HD'}, '%s/bein7.png'% ART)
    add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/357.ts',{ 'title': 'BEINSPORTS 8 HD'}, '%s/bein8.png'% ART)
    add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/358.ts',{ 'title': 'BEINSPORTS 9 HD'}, '%s/bein9.png'% ART)
    add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/359.ts',{ 'title': 'BEINSPORTS 10 HD'}, '%s/bein10.png'% ART)
    add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/360.ts',{ 'title': 'BEINSPORTS 11 HD'}, '%s/bein11.png'% ART)
    add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/361.ts',{ 'title': 'BEINSPORTS 12 HD'}, '%s/bein12.png'% ART)
    add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/362.ts',{ 'title': 'BEINSPORTS 13 HD'}, '%s/bein13.png'% ART)
    add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/363.ts',{ 'title': 'BEINSPORTS 14 HD'}, '%s/bein14.png'% ART)
    add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/364.ts',{ 'title': 'BEINSPORTS 15 HD'}, '%s/bein15.png'% ART)
    add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/1543.ts',{ 'title': 'CTH Stadium 1 HD'}, '%s/cthstadium1.jpg'% ART)
    add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/1542.ts',{ 'title': 'CTH Stadium 2 HD'}, '%s/cth2.jpg'% ART)
    add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/1541.ts',{ 'title': 'CTH Stadium 3 HD'}, '%s/cth3.jpg'% ART)
    add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/1540.ts',{ 'title': 'CTH Stadium 4 HD'}, '%s/cth4.jpg'% ART)
    add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/1539.ts',{ 'title': 'CTH Stadium 5 HD'}, '%s/cth5.jpg'% ART)
    add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/1538.ts',{ 'title': 'CTH Stadium 6 HD'}, '%s/cth6.png'% ART)
    add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/2009.ts',{ 'title': 'CTH Stadium X HD'}, '%s/cthx.jpg'% ART)
    add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/547.ts',{ 'title': 'Arena Sports 1 HD'}, '%s/arena.jpg'% ART)
    add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/548.ts',{ 'title': 'Arena Sports 2 HD'}, '%s/arena.jpg'% ART)
    add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/549.ts',{ 'title': 'Arena Sports 3 HD'}, '%s/arena.jpg'% ART)
    add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/550.ts',{ 'title': 'Arena Sports 4 HD'}, '%s/arena.jpg'% ART)
    add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/551.ts',{ 'title': 'Arena Sport 1 Srb'}, '%s/arena.jpg'% ART)
    add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/552.ts',{ 'title': 'Arena Sport 2 Srb'}, '%s/arena.jpg'% ART)
    add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/553.ts',{ 'title': 'Arena Sport 3 Srb'}, '%s/arena.jpg'% ART)
    add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/554.ts',{ 'title': 'Arena Sport 4 Srb'}, '%s/arena.jpg'% ART)
    add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/555.ts',{ 'title': 'Arena Sport 5 Srb'}, '%s/arena.jpg'% ART)
    add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/541.ts',{ 'title': 'Sport Klub HD 1 Cro'}, '%s/klub.png'% ART)
    add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/542.ts',{ 'title': 'Sport Klub HD 2 Cro'}, '%s/klub.png'% ART)
    add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/543.ts',{ 'title': 'Sport Klub HD 3 Cro'}, '%s/klub.png'% ART)
    add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/544.ts',{ 'title': 'Sport Klub 1 Srb'}, '%s/klub.png'% ART)
    add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/545.ts',{ 'title': 'Sport Klub 2 Srb'}, '%s/klub.png'% ART)
    add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/546.ts',{ 'title': 'Sport Klub 3 Srb'}, '%s/klub.png'% ART)
    add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/1532.ts',{ 'title': 'Ten Sports (PK)'}, '%s/ten.jpg'% ART)
    add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/1696.ts',{ 'title': 'PTV Sports (PK)'}, '%s/ptv.jpg'% ART)
    add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/2011.ts',{ 'title': 'Willow Cricket'}, '%s/willow.jpg'% ART)
    add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/1579.ts',{ 'title': 'WWE Channel'}, '%s/wwf.png'% ART)
    add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/942.ts',{ 'title': 'Canada Sport: SNWL'}, '%s/canada.png'% ART)
    add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/529.ts',{ 'title': 'NBA TV'}, '%s/nba.jpg'% ART)
    add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/1406.ts',{ 'title': 'BG: Sportal Tv'}, '%s/sportal.jpg'% ART)
    
def UK_MUSIC():	
    
    add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/381.ts',{ 'title': 'VEVO MUSIC 1'}, '%s/vevo.jpg'% ART)
    add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/440.ts',{ 'title': 'VEVO MUSIC 2'}, '%s/vevo.jpg'% ART)
    add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/441.ts',{ 'title': 'VEVO MUSIC 3'}, '%s/vevo.jpg'% ART)
    add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/913.ts',{ 'title': 'Virgin TV'}, '%s/virgintv.png'% ART)
    add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/472.ts',{ 'title': 'MTV Music HD'}, '%s/mtv.png'% ART)
    add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/471.ts',{ 'title': 'MTV HITS'}, '%s/hits.png'% ART)
	
def USA_TV():	
     
    add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/1677.ts',{ 'title': 'Pbs America'}, '%s/pbs.png'% ART)
    add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/1635.ts',{ 'title': 'SPIKE'}, '%s/spike.png'% ART)
    add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/1636.ts',{ 'title': 'FOOD NETWORK'}, '%s/foodnetwork.png'% ART)
    add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/1633.ts',{ 'title': 'CNBC'}, '%s/cnbc.png'% ART)
    add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/1580.ts',{ 'title': 'AMC'}, '%s/amc.png'% ART)
    add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/1280.ts',{ 'title': 'HD MEDIA 3D'}, '%s/hd3d.jpg'% ART)
    add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/556.ts',{ 'title': 'TSN 1 HD'}, '%s/tsn1.png'% ART)
    add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/557.ts',{ 'title': 'TSN 2 HD'}, '%s/tsn2.png'% ART)
    add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/558.ts',{ 'title': 'TSN 3 HD'}, '%s/tsn3.png'% ART)
    add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/559.ts',{ 'title': 'TSN 4 HD'}, '%s/tsn4.png'% ART)
    add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/560.ts',{ 'title': 'TSN 5 HD'}, '%s/tsn5.png'% ART)
    add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/1296.ts',{ 'title': 'PAC National HD'}, '%s/pac.jpg'% ART)
    add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/1614.ts',{ 'title': 'NBCSN'}, '%s/nbcsn.jpg'% ART)
    add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/1615.ts',{ 'title': 'NBC Golf Channel'}, '%s/golf.png'% ART)
    add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/570.ts',{ 'title': 'USA Network HD'}, '%s/usa.png'% ART)
    add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/1286.ts',{ 'title': 'USA: TNT'}, '%s/tnt.png'% ART)
    add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/571.ts',{ 'title': 'TBS USA HD'}, '%s/tbs.png'% ART)
    add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/572.ts',{ 'title': 'SyFy'}, '%s/syfyhd.png'% ART)
    add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/1731.ts',{ 'title': 'Sportsnet 1'}, '%s/sportsnet1.jpg'% ART)
    add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/1616.ts',{ 'title': 'Sportsnet Ontario'}, '%s/sportson.jpg'% ART)
    add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/568.ts',{ 'title': 'SportsNet 360'}, '%s/sports360.png'% ART)
    add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/1295.ts',{ 'title': 'PAC-12 Net. (Arizona)'}, '%s/pac.jpg'% ART)
    add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/1294.ts',{ 'title': 'PAC-12 Net. (Bay Area)'}, '%s/pac.jpg'% ART)
    add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/1293.ts',{ 'title': 'PAC-12 Net. (Los Angeles)'}, '%s/pac.jpg'% ART)
    add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/1292.ts',{ 'title': 'PAC-12 Net. (Moutain)'}, '%s/pac.jpg'% ART)
    add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/1291.ts',{ 'title': 'PAC-12 Net. (Oregon)'}, '%s/pac.jpg'% ART)
    add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/1290.ts',{ 'title': 'PAC-12 Net. (Washington)'}, '%s/pac.jpg'% ART)
    add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/1289.ts',{ 'title': 'Big Ten Network'}, '%s/btn.jpg'% ART)
    add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/582.ts',{ 'title': 'A&E'}, '%s/a&e.jpg'% ART)
    add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/573.ts',{ 'title': 'NFL HD'}, '%s/nfl.png'% ART)
    add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/574.ts',{ 'title': 'HBO HD'}, '%s/hbohd.png'% ART)
    add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/576.ts',{ 'title': 'Fox Sports 1'}, '%s/fox1.jpg'% ART)
    add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/575.ts',{ 'title': 'Fox Sports 2'}, '%s/fox2.jpg'% ART)
    add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/577.ts',{ 'title': 'ESPN HD'}, '%s/espnhd.png'% ART)
    add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/1928.ts',{ 'title': 'CNN'}, '%s/cnn.png'% ART)
    add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/569.ts',{ 'title': 'ABC NEWS HD'}, '%s/abcnews.jpg'% ART)
    add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/2092.ts',{ 'title': 'Showtime'}, '%s/showtime.png'% ART)
    add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/1892.ts',{ 'title': 'WGN 9 News'}, '%s/wgn.png'% ART)
    add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/1902.ts',{ 'title': 'Travel Channel'}, '%s/travel.jpg'% ART)
    add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/1901.ts',{ 'title': 'TLC'}, '%s/tlc.png'% ART)
    add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/1903.ts',{ 'title': 'Planet Green'}, '%s/planet.png'% ART)
    add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/1898.ts',{ 'title': 'Miami TV'}, '%s/miami.jpg'% ART)
    add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/1904.ts',{ 'title': 'Investigation Discovery'}, '%s/dicoveryid.png'% ART)
    add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/1907.ts',{ 'title': 'HBO Plus'}, '%s/hbo2.png'% ART)
    add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/1906.ts',{ 'title': 'Discovery Science HD'}, '%s/discoscience.png'% ART)
    add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/1905.ts',{ 'title': 'Discovery Channel HD'}, '%s/discoveryhd.png'% ART)
    add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/1911.ts',{ 'title': 'CBS PGA Tour'}, '%s/pga.jpg'% ART)
    add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/1909.ts',{ 'title': 'CBS'}, '%s/cbs.hd'% ART)
    add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/1893.ts',{ 'title': 'Bloomberg'}, '%s/bloomberg.png'% ART)
    add_video_item('http://iptvspeedy4you.ddns.net:8000/live/'+USER+'/'+PASSWORD+'/1900.ts',{ 'title': 'Animal Planet'}, '%s/animalhd.png'% ART)
	

def addDir(name,url,mode,iconimage,fanart,description):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&fanart="+urllib.quote_plus(fanart)+"&description="+urllib.quote_plus(description)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name, "Plot": description } )
        liz.setProperty( "Fanart_Image", fanart )
        if mode==5 :
            ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
        else:
            ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok
def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param

N = base64.decodestring('')
T = base64.decodestring('L2FkZG9ucy50eHQ=')
B = base64.decodestring('')
F = base64.decodestring('')
def addDir(name,url,mode,iconimage,fanart,description):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&fanart="+urllib.quote_plus(fanart)+"&description="+urllib.quote_plus(description)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name, "Plot": description } )
        liz.setProperty( "Fanart_Image", fanart )
        if mode==5 :
            ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
        else:
            ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok    

        
                      
params=get_params()
url=None
name=None
mode=None
iconimage=None
fanart=None
description=None


try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        iconimage=urllib.unquote_plus(params["iconimage"])
except:
        pass
try:        
        mode=int(params["mode"])
except:
        pass
try:        
        fanart=urllib.unquote_plus(params["fanart"])
except:
        pass
try:        
        description=urllib.unquote_plus(params["description"])
except:
        pass
        
        
print str(PATH)+': '+str(VERSION)
print "Mode: "+str(mode)
print "URL: "+str(url)
print "Name: "+str(name)
print "IconImage: "+str(iconimage)


def setView(content, viewType):
    # set content type so library shows more views and info
    if content:
        xbmcplugin.setContent(int(sys.argv[1]), content)
    if ADDON.getSetting('auto-view')=='true':
        xbmc.executebuiltin("Container.SetViewMode(%s)" % ADDON.getSetting(viewType) )

if mode==None or url==None or len(url)<1:
        INDEX()

elif mode==2:
        UK()
        
elif mode==3:
        UK_MOVIES()

elif mode==4:
        UK_SPORTS()

elif mode==6:
        UK_DOCUMENTARIES()
		
elif mode==7:
        UK_ENTERTAINMENT()

elif mode==8:
        UK_KIDS()		
		
elif mode==9:
        UK_INDIAN()
		
elif mode==10:
        EURO_SPORTS()
		
elif mode==11:
        UK_MUSIC()
		
elif mode==12:
        USA_TV()




xbmcplugin.endOfDirectory(plugin_handle)
xbmc.executebuiltin("Container.SetViewMode(500)")


